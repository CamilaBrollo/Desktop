https://docs.google.com/document/d/1aqRob9OD-Gvac-8JM1ftJ53WhiPakWveNxvVAORf4C4/edit?usp=sharing
